# Digital Pre‑Need Portal — Spec (v0.1)

- E‑sign workflows; trust funding to Master Pre‑Need Trust.
- PCI‑compliant payment gateway.
- Contract variants: Retail, Wholesale, Pay‑It‑Forward Soil.
- Admin dashboard: maturity schedule, cancellations, trust reconciliations.
