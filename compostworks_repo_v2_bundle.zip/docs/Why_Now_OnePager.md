# Why Now — One Pager (California 2027)

- **Regulatory window**: California licensing for NOR activates Jan 1, 2027.
- **Consumer pull**: Majority of Americans open to green funerals; cremation mainstreamed.
- **Cost & climate**: NOR undercuts burial by thousands; avoids ~1 t CO₂ per case.
- **Capacity gap**: Few operators; wholesale demand from funeral homes rising.
- **Community value**: Soil heals local lands; measurable ESG for partners/hospices.
