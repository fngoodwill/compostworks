# Permitting Checklist — Bakersfield (Kern County)

- Zoning/CUP: Kern County Planning & Natural Resources (M‑1/M‑2 preferred).
- Air: San Joaquin Valley APCD — Authority to Construct + Permit to Operate.
- Building/Fire: City of Bakersfield (if in city) or County Building Inspection.
- State: CA Cemetery & Funeral Bureau — Reduction Facility licence (2027).
- OSHA: Exposure Control Plan, annual training; equipment lock-out/tag-out.
- Documentation: SOP v2, Odor Control Plan, HVAC negative‑pressure specs, Temp‑log QA.
