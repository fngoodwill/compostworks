# Risk Register (Extract)

- Odor complaints → Mitigation: biofilter + negative pressure, monitoring.
- Regulatory delay → Mitigation: dual‑track out‑of‑state partner; early filings.
- Talent retention → Mitigation: Team Charter, authorship credit, flexible schedules.
- Insurance gaps → Mitigation: GL + pollution + professional liability; broker with NOR experience.
