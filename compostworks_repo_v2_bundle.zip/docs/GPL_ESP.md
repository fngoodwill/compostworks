# Lista General de Precios (ESP)

**Estándar Verde** — $6,450 (todo incluido)
**Verde Plus** — $6,950 (incluye urna de recuerdo + kit de semillas)
**Socio Mayorista** — $4,950 (SLA 48 h; marca blanca)
*Incluye traslado ≤75 millas, proceso NOR, ½ yarda³ de suelo, árbol con GPS, Certificado de Carbono y acceso a CompostTrack™.*
