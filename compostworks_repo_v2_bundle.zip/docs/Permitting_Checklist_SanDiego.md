# Permitting Checklist — San Diego County

- CUP / CEQA: County Planning; odor model & initial study.
- Air: San Diego APCD — Authority to Construct.
- Building/Fire: Local jurisdiction permit; NFPA 13 sprinklers where applicable.
- State: CA Cemetery & Funeral Bureau — Reduction Facility licence (2027).
- OSHA: Exposure Control Plan; LOTO; confined space if applicable.
- Documentation: SOP v2, Odor Plan, negative‑pressure HVAC drawings, lab testing SOP.
