# Staffing Plan (Pilot — 10 vessels)

- Facility Manager (Licensed FD / Reduction Operator)
- Operators (2–3) — CANA NOR certificate + OSHA BBP
- Quality & Lab Tech — microbiology/soil science
- Transport Lead — OSHA BBP; clean DMV
- Admin/Outreach — bilingual ENG/ESP

Recruit via NFDA Career Center, US Composting Council, local colleges (Fresno State, Cal Poly).
