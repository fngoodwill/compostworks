# KPI Dictionary

- Cases per Month
- Turnaround Time (intake → soil release)
- Compliance Pass Rate (temp logs, assays)
- Net Promoter Score (family survey)
- CO₂ Saved per Case (modeled)
- Soil Donated (cu yd)
- Wholesale Partner SLA %
