# Outreach Talking Points (Hospice / Hospital / Funeral Homes)

- Faster discharge & cooler relief; 24/7 retrieval line.
- Climate‑positive: ~1 t CO₂ avoided per case; ESG reporting.
- Family‑centric: Laying‑In ceremony; CompostTrack™ transparency.
- Wholesale: 48‑hr turnaround; white‑label options.
