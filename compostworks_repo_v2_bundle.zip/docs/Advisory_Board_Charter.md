# Advisory Board Charter (Draft)

Purpose: Provide technical, regulatory, financial, and community guidance.
Seats: Licensed FD, Soil Scientist PhD, Environmental Justice rep, CFO/CPA.
Meetings: Quarterly; special sessions during permitting.
Compensation: Modest stipend or travel; public recognition (opt‑in).
