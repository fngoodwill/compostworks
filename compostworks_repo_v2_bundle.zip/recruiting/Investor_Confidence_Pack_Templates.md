# Investor Confidence Pack — Templates

## Founder Resume (2 pages)
- Summary (mission + KPIs)
- Regulatory readiness
- Market access LOIs
- Financial discipline (DSCR)
- Advisory board & team
- Credentials (CANA, OSHA)

## LinkedIn "About"
Mission, timing (CA 2027), capacity ramp, pricing band, impact, partner asks.

## Data Room Checklist
Decks, SOPs, checklists, LOIs, models, charts, legal drafts, governance, policies.
