# Job Descriptions (Extracts)

## Facility Manager (Licensed FD)
- Requirements: CA Funeral Director license; CANA NOR cert.
- Leads compliance, training, family experience.

## NOR Operator
- Requirements: OSHA BBP; CANA NOR certificate.
- Runs vessels; logs temps; safety procedures.

## Lab/Quality Tech
- Requirements: Microbiology/soil science.
- Pathogen assays; heavy‑metal testing; QA logs.

## Software Engineer (CompostTrack)
- Requirements: Backend + mobile; API + QR workflow.
- Family portal; regulator export; privacy.
