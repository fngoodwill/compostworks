# Team Charter — Non‑Monetary Offers

- Mission & measured impact dashboard (public credit)
- Inventorship/authorship on modules & whitepapers
- Conference sponsorships & speaking
- Autonomy via technical ownership areas
- Governance seats (advisory council)
- Place‑based legacy (named memorial groves)
- Learning time & mini‑sabbaticals
- Flexible work designs (9/80, async)
- Ethical Tech & Dignity Charter
