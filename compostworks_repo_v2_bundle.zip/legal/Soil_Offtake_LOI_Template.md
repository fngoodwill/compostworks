# Soil Off‑Take LOI (Template)

- Receiving Partner: [Land Trust / Park / Orchard]
- Annual volume: up to [__] cu yd
- Quality: Class A pathogen standards; heavy‑metal panel attached
- Delivery/collection logistics; publicity rights; reporting
