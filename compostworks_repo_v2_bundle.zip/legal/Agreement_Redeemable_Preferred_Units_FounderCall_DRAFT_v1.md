# Redeemable Preferred Membership Interest Purchase Agreement (Draft Outline)

- Definitions; Class P rights; distribution waterfall.
- Minimum Return; calculation mechanics; reporting.
- Founder Call; Redemption mechanics; FMV formula; floor/cap.
- Negative covenants; SBA carve‑outs; security interest.
- Reps & warranties; indemnities; governing law.
*Have counsel draft the final agreement.*
