# Wholesale Partner MOU (Template)

- Fixed per‑case wholesale fee ($4,950)
- SLA: 48‑hr turnaround (intake → vessel load)
- White‑label family communications (optional)
- Chain‑of‑custody and compliance responsibilities
- Billing & settlement terms
