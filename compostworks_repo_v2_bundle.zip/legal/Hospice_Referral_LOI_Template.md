# Hospice Referral LOI (Template)

- Referral process; 24/7 line; retrieval within [3] hours
- Family education materials; bilingual brochures
- Data privacy + compliance
- Modest admin fee or training credit (as permitted)
