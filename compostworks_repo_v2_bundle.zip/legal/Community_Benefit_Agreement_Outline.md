# Community Benefit Agreement (Outline)

- Local hire (25%); bilingual services; open houses
- Soil donation to urban gardens; school partnerships
- Annual public impact report; advisory council seats
