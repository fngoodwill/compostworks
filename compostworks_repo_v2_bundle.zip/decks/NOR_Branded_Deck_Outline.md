# NOR Branded Deck — Outline (V2 / Lender‑Ready)

1. Title & Mission
2. Why Now (CA 2027, demand, pricing, ESG)
3. Product & SOP v2 (CompostTrack™, carbon cert, GPL)
4. Market & Competition (wholesale channel)
5. Site & Permitting (Bakersfield timeline)
6. Team & Advisors (licensed FD, soil scientist, CFO)
7. Pricing & Packages (ENG/ESP)
8. Models & Scenarios (charts included)
9. Use of Funds (detailed) & Sources of Funds (SBA 504/7a)
10. Underwriting Case (DSCR) & Break‑Even
11. Risks & Mitigations
12. Community Impact & Soil‑Healing
13. Next Steps & Ask
